package com.devsuperior.hreurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
